// Default program for dealing with various standard TRIUMF VME setups:
// V792, V1190 (VME), L2249 (CAMAC), Agilent current meter
//
//

#include <stdio.h>
#include <iostream>
#include <time.h>

#include "TAnaManager.hxx"
#include "TRootanaEventLoop.hxx"
#include "TTree.h"
#include "TV792Data.hxx"
#include "TV1190Data.hxx"

#include <TH1F.h>
#include <TH2F.h>


class Analyzer: public TRootanaEventLoop {

private:
	TTree* evts;
	Int_t n_evts;
	Double_t si1 = 0 , si2 = 0 , ge = 0 , si1t = 0 , si2t = 0 , GeTi = 0 ;
	TH1F* ESi1; // Pulser spectrum
	TH1F* ESi2; // Si spectrum
	TH1F* EGe;
	TH1F* Echannel[32];
	TH1F* Tevents; // T spectrum
	TH1F* ESi1t; // Pulser spectrum
	TH1F* ESi2t; // Si spectrum
	TH1F* EGeTi; // Si spectrum
	TH1F* Echannelt[32];
	TH2F* EdE; // E-dE 2-D spectrum
	TH2F* Es1vEs2;
	TH2F* EgvEs1;
	TH2F* EgvEs2;
	TH1F* TSi1vSi2;
	TH1F* TSi1vGe;
	TH1F* TSi2vGe;
	TH1F* TdSivGe;
        std::vector<VADCMeasurement> measurements;


public:

  // An analysis manager.  Define and fill histograms in 
  // analysis manager.
  TAnaManager *anaManager;
  
  Analyzer() {
    //DisableAutoMainWindow();
    //UseBatchMode();

    // Initialize pointers to null
    anaManager = 0;
	ESi1 = 0;
	ESi2 = 0;    
	EGe = 0;
	Tevents = 0;
	TSi1vSi2 = 0;
	TSi1vGe = 0;
	TSi2vGe = 0;
	TdSivGe = 0;
	n_evts = 0;
	si1 = -1;si2 = -1;ge = -1;si1t = -1;si2t = -1;GeTi = -1;
  };

  virtual ~Analyzer() {};

  void Initialize(){

#ifdef HAVE_THTTP_SERVER
    std::cout << "Using THttpServer in read/write mode" << std::endl;
    SetTHttpServerReadWrite();
#endif

  }

  void InitManager(){
    
    if(anaManager)
      delete anaManager;
    anaManager = new TAnaManager();
    
  }
  
  
  void BeginRun(int transition,int run,int time){
    
    InitManager();
	// delete old histogram, if it exists.
/*	TH1F *old = (TH1F*)gDirectory->Get("ESi1");
	if (old) delete old;
	TH1F *old = (TH1F*)gDirectory->Get("ESi2");
	if (old) delete old;*/
	evts = new TTree("evts", "evts");
	evts->Branch("n_evts",&n_evts,"Event_number/L");
	evts->Branch("si1",&si1,"Si1/D");
	evts->Branch("si2",&si2,"Si2/D");
	evts->Branch("ge",&ge,"Ge/D");
	evts->Branch("si1t",&si1t,"Si1_time/D");
	evts->Branch("si2t",&si2t,"Si2_time/D");
	evts->Branch("GeTi",&GeTi,"Ge_time/D");
	ESi1 = new TH1F("ESi1","Silicon 1 spectrum",4096,0,16384); // create new histogram
	ESi2 = new TH1F("ESi2","Silicon 2 spectrum",4096,0,16384); // create new histogram
	EGe = new TH1F("EGe","Ge spectrum",4096,0,16384); // create new histogram
	ESi1t = new TH1F("ESi1t","Silicon 1 TDC Spectrum",4200,0,4200); // create new histogram
	ESi2t = new TH1F("ESi2t","Silicon 2 TDC Spectrum",4200,0,4200); // create new histogram
	EGeTi = new TH1F("EGeTi","Ge TDC Spectrum",4096,0,16384); // create new histogram
	EdE = new TH2F("EdE","E-deltaE spectrum",4200,0,4200,4200,0,4200); // create new histogram
	Es1vEs2 = new TH2F("Es1vEs2","Si1-Si2 spectrum",4200,0,4200,4200,0,4200); // create new histogram
	EgvEs1 = new TH2F("EgvEs1","Ge-Si1 spectrum",4200,0,4200,4200,0,4200); // create new histogram
	EgvEs2 = new TH2F("EgvEs2","Ge-Si2 spectrum",4200,0,4200,4200,0,4200); // create new histogram
	Tevents = new TH1F("Tevents","Events",2000000,-1000000,1000000); // create new histogram
	TSi1vSi2 = new TH1F("TSi1vSi2","Si1 v Si2",200000,-100000,100000); // create new histogram
	TSi1vGe = new TH1F("TSi1vGe","Si1 v Ge",200000,-100000,100000); // create new histogram
	TSi2vGe = new TH1F("TSi2vGe","Si2 v Ge",200000,-100000,100000); // create new histogram
	TdSivGe = new TH1F("TdSivGe","dSi v Ge",200000,-100000,100000); // create new histogram
	for(unsigned int i = 0; i < 32; i++){ // loop over measurements
		Echannel[i] = new TH1F(std::string ("Echannel["+std::to_string(i)+"]").c_str(),std::string ("Channel "+std::to_string(i)).c_str(),4096,0,16384);
		Echannelt[i] = new TH1F(std::string ("Echannelt["+std::to_string(i)+"]").c_str(),std::string ("TChannel "+std::to_string(i)).c_str(),4096,0,16384);
	}
  }


  bool ProcessMidasEvent(TDataContainer& dataContainer){

/*    if(!anaManager) InitManager();
    
    anaManager->ProcessMidasEvent(dataContainer);
	return true;*/ //fuck you (for now)

    //Get pointer to decoded ADC
	++n_evts;
    TV792Data *data = dataContainer.GetEventData<TV792Data>("QDC0");
	Tevents->Fill(dataContainer.GetMidasData().GetTimeStamp()-1522538377);
	si1 = 0;si2 = 0;ge = 0;si1t = 0;si2t = 0;GeTi = 0;
//	std::cout << dataContainer.GetMidasData().GetEventId();
    if(data){
      // Loop over all measurement for all channels
      measurements = data->GetMeasurements();
      for(unsigned int i = 0; i < measurements.size(); i++){ // loop over measurements
//	std::cout << i << "/" << measurements.size() << ": " << "chan" << measurements[i].GetChannel() << " " << measurements[i].GetMeasurement() << std::endl;
//	std::cout << dataContainer.GetMidasData().GetTimeStamp()-1509009600-1419400-4294967236<<std::endl;
        	Echannel[i]->Fill(measurements[i].GetMeasurement());
	if(measurements[i].GetChannel()==0)
		si1 = measurements[i].GetMeasurement();
        	ESi1->Fill(si1);
	if(measurements[i].GetChannel()==2)
		si2 = measurements[i].GetMeasurement();
        	ESi2->Fill(si2);
	if(measurements[i].GetChannel()==4)
		ge = measurements[i].GetMeasurement();
        	EGe->Fill(ge);
      }
    }
    TV1190Data *datat = dataContainer.GetEventData<TV1190Data>("TDC0");
    if(datat){
//	datat->Print();
      // Loop over all measurement for all channels
      std::vector<TDCMeasurement> measurementst = datat->GetMeasurements();
      for(unsigned int i = 0; i < measurementst.size(); i++){ // loop over measurements
//	std::cout << dataContainer.GetMidasData().GetTimeStamp() << ":  " << measurementst[i].GetChannel() << ", " << measurementst[i].GetMeasurement() <<std::endl;
        	Echannelt[i]->Fill(measurementst[i].GetMeasurement());
	if(i==1)
		{
		si1t = measurementst[i].GetMeasurement();
        	ESi1t->Fill(si1t);
		TSi1vGe->Fill(measurementst[1].GetMeasurement()-measurementst[0].GetMeasurement());
			if (measurementst[1].GetMeasurement()-measurementst[0].GetMeasurement() < 760 && measurementst[1].GetMeasurement()-measurementst[0].GetMeasurement() > 720 && data)
			{
				EgvEs1->Fill(measurements[4].GetMeasurement(), measurements[0].GetMeasurement());
			}
		}
	if(i==0)
		GeTi = measurementst[i].GetMeasurement();
        	EGeTi->Fill(GeTi);
	if(i==2)
		{
		si2t = measurementst[i].GetMeasurement();
        	ESi2t->Fill(si2t);
			if (measurementst[2].GetMeasurement()-measurementst[1].GetMeasurement() < 760 && measurementst[2].GetMeasurement()-measurementst[1].GetMeasurement() > 720 && data)
			{
				EdE->Fill(measurements[0].GetMeasurement(), measurements[0].GetMeasurement() - measurements[2].GetMeasurement());
				Es1vEs2->Fill(measurements[0].GetMeasurement(), measurements[2].GetMeasurement());
			}
			if (measurementst[2].GetMeasurement()-measurementst[0].GetMeasurement() < 760 && measurementst[2].GetMeasurement()-measurementst[0].GetMeasurement() > 720 && data)
			{
				EgvEs2->Fill(measurements[4].GetMeasurement(), measurements[2].GetMeasurement());
			}
		TSi1vSi2->Fill(measurementst[2].GetMeasurement()-measurementst[1].GetMeasurement());
		TSi2vGe->Fill(measurementst[2].GetMeasurement()-measurementst[0].GetMeasurement());
		}
      }
//	TdSivGe = new TH1F("TdSivGe","dSi v Ge",200000,-100000,100000); // create new histogram
    }
		std::cout << n_evts << ":" << si1 <<  ":" << si2 <<  ":" << ge <<  ":" << si1t <<  ":" << si2t <<  ":" << GeTi <<  "\n";
    evts->Fill();
    return true;
  
  }


}; 


int main(int argc, char *argv[])
{

  Analyzer::CreateSingleton<Analyzer>();
  return Analyzer::Get().ExecuteLoop(argc, argv);

}

